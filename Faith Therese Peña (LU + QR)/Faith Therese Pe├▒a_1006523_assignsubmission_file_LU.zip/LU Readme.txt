Faith Therese F. Pena
2013-41489
CS131 THR



=====================================================================================
To run LUdecompCrout:

$ javac main.java
$ java main x

where x is a positive integer representing the row and column of your input matrix
=====================================================================================


NOTES WHEN INPUTTING VALUES:
> Make sure your inputs are WHOLE NUMBERS or are in DECIMAL. Do NOT write equations
  (ex. 0-1). Do NOT input fractions.


Java version of author:
openjdk version "1.8.0_92"
OpenJDK Runtime Environment (build 1.8.0_92-b14)
OpenJDK 64-Bit Server VM (build 25.92-b14, mixed mode)
