Faith Therese F. Pena
2013-41489
CS131 THR



=====================================================================================
To run QRFactorization:

$ javac -cp './:jama.jar' *.java
$ java -cp './:jama.jar' main x

where x is a positive integer representing the row and column of your input matrix

(If you're in Windows, use ; instead of :)
=====================================================================================

NOTES WHEN INPUTTING VALUES:
> Make sure your inputs are WHOLE NUMBERS or are in DECIMAL. Do NOT write equations
  (ex. 0-1). Do NOT input fractions.


Java version of author:
openjdk version "1.8.0_92"
OpenJDK Runtime Environment (build 1.8.0_92-b14)
OpenJDK 64-Bit Server VM (build 25.92-b14, mixed mode)
