# CS 131 LE 3 Numerical Methods Implementation

**Package Name:** `edu.up.numeds`

**Author:** Vincent Fiestada <vffiestada@gmail.com>

This package consists of a Java class library with classes for LU-decomposable matrices and Lagrange Interpolators, as well as a simply JavaFX application that consumes the class library. These components are described below. 

The class library is designed to be separate from the GUI application and as generic as possible. For more information, please see the in-code documentation for the various classes.

## Matrix 

A basic representation of a square matrix with methods to access and change any element within the matrix.

## DecomposableMatrix 

**Extends `Matrix`**

An extension of Matrix that can be decomposed into LU using Crout's Method. Decomposition must be manually triggered. The L and U matrices are maintained internally.

## Interpolator 

*(Abstract)*

An abstract 2D Interpolator class which exposes various APIs useful for interpolation. It maintains an internal list of known points used for interpolation. The concrete implementation is left out, for example, the LagrangeInterpolator class implements this class using Lagrange Polynomial interpolation.

## LagrangeInterpolator

**Extends `Interpolator`**

A concrete implementation of `Interpolator`, which uses Lagrange polynomial interpolation. This class uses Doubles but can be easily modified to use other subclasses of Number such as BigInteger, BigDecimal, etc.

## NumericalMethods

*[Main Class]*

This is the main class of the package, and the entry point for the JavaFX GUI application. It consumes the aforementioned class library and provides a graphical interface for relatively easy use of the numerical methods.

## How to Run

First, make sure you have the following prerequisites installed on your machine and added to your PATH variable:

- Java Runtime Environment 1.8.0_112-b15
- Gradle 3.1

The project is written in Java and requires the Java runtime to be used. Gradle is the build system used.

### Compiling from Source

To compile from the source code using Gradle, run the following command in the project directory.

```
gradle build
```

### Running Jar file 

Gradle should create a jar file inside `build\libs\numerical_methods.jar`. Execute this to use the application:

```
java -jar build\libs\numerical_methods.jar
```

## Usage

When you open the application, it will show you a menu where you can choose a Numerical Method to use. Click the appropriate button to open a new window with the GUI for that method.

![](images/screen_menu.png)

### Lagrange Interpolation

The Lagrange Interpolation screen consists of two tabs. The first tab has the tables for the list of known points and the list of interpolated points. You may add and delete points from these tables using the corresponding controls at the bottom. For the interpolated points, you can only enter an x-value. The y-value will be automatically interpolated.

![](images/screen_lagrange_tab1.png)

The second tab contains a graph of the points on both tables. To update the graph, click the "Re-plot Points" button.

![](images/screen_lagrange_tab2.png)

### Crout's Method 

The Crout's Method screen consists of three tabs, one each for the A, L, and U matrices. Only the A matrix can be edited. To change the dimensions of the A matrix, Enter a number in the "Size of A" field at the bottom and click "Reset". You can edit the value of each element in A by double-clicking the appropriate cell, typing a value, and pressing Enter. 

To calculate the L and U matrices, click the "Decompose A" button.

![](images/screen_crout_tab1.png)

### Export as CSV

Both screens offer you the ability to export the data as CSV. You can choose where to save the file in the File Save dialog that appears.

Lagrange will export a table of all the points with X and Y coordinates, as well as a third column, "Interpolated?". This column will contain "Yes" if the point was interpolated and "No" if it was given.

Crout's method will export a spreadsheet containing the three matrices in the following order: A, L, U. Each matrix will be separated from the one on top by a blank row.